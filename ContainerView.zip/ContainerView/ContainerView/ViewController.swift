//
//  ViewController.swift
//  ContainerView
//
//  Created by syed fazal abbas on 08/05/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var ViewResult: UIView!
    @IBOutlet var lblHeading: UILabel!
    @IBOutlet var AddDetail: UIView!
    @IBOutlet var btnViewResult: UIButton!
    @IBOutlet var btnAddStudent: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupBtnUI()
    }
    func setupBtnUI(){
        btnViewResult.layer.cornerRadius = 5
        btnViewResult.layer.masksToBounds = true
        btnViewResult.clipsToBounds = false
        btnAddStudent.layer.cornerRadius = 5
        btnAddStudent.layer.masksToBounds = true
        btnAddStudent.clipsToBounds = false
    }
    func setupUI(){
        lblHeading.isHidden = true
        ViewResult.isHidden = true
        AddDetail.isHidden = true
        
    }
    @IBAction func btnTappedViewResult(_ sender: UIButton) {
        lblHeading.text = "Student Result"
        ViewResult.isHidden = false
        AddDetail.isHidden = true
        lblHeading.isHidden = false
    }
    
    @IBAction func btnTappedAddStudent(_ sender: UIButton) {
        lblHeading.text = "Add Detail"
        ViewResult.isHidden = true
        AddDetail.isHidden = false
        lblHeading.isHidden = false
    }
    @IBAction func btnBack(_ sender: UIButton) {
        setupUI()
    }
}

