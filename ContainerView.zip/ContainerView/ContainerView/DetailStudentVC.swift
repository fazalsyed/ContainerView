//
//  DetailStudentVC.swift
//  ContainerView
//
//  Created by syed fazal abbas on 08/05/23.
//

import UIKit

class DetailStudentVC: UIViewController {

    @IBOutlet var btnSubmit: UIButton!
    @IBOutlet var myView: UIView!
    @IBOutlet var stackView: UIStackView!
    override func viewDidLoad() {
        super.viewDidLoad()
        setupStackUI()
        btnUI()
    }
    func setupStackUI(){
        myView.layer.cornerRadius = 10
        myView.layer.borderWidth = 1
        myView.layer.borderColor = UIColor.black.cgColor
        myView.layer.masksToBounds = true
        myView.clipsToBounds = false
    }
    
    func btnUI(){
        btnSubmit.layer.cornerRadius = 5
        btnSubmit.layer.borderWidth = 1
        btnSubmit.layer.borderColor = UIColor.black.cgColor
        btnSubmit.layer.masksToBounds = true
        btnSubmit.clipsToBounds = false
    }
}
