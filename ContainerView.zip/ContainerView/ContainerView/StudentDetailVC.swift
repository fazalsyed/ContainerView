//
//  StudentDetailVC.swift
//  ContainerView
//
//  Created by syed fazal abbas on 08/05/23.
//

import UIKit

class StudentDetailVC: UIViewController {

    @IBOutlet var tableView: UITableView!
    var SubArray = ["C","C++","Java","PHP","DataStructure","BigData","C","C++","Java","PHP","DataStructure","BigData"]
    var SubNumArray = ["60","80","75","65","56","76","60","80","75","65","56","76"]
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UINib(nibName: "CellT_DetailStudent", bundle: nil), forCellReuseIdentifier: "CellT_DetailStudent")
    }
}

extension StudentDetailVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return SubArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CellT_DetailStudent") as? CellT_DetailStudent
        cell?.lblSubName.text = SubArray[indexPath.row]
        cell?.lblSubNum.text = SubNumArray[indexPath.row]
        cell?.view.layer.cornerRadius = 10
        cell?.layer.masksToBounds = true
        cell?.clipsToBounds = false
        cell?.view.layer.borderColor = UIColor.black.cgColor
        cell?.view.layer.borderWidth = 1
        return cell!
    }
}
