//
//  CellT_DetailStudent.swift
//  ContainerView
//
//  Created by syed fazal abbas on 08/05/23.
//

import UIKit

class CellT_DetailStudent: UITableViewCell {

    @IBOutlet var view: UIView!
    @IBOutlet var lblSubName: UILabel!
    @IBOutlet var lblSubNum: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
